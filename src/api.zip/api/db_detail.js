//数据库配置详情
module.exports = {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'crowdfunding_db'
  };
  