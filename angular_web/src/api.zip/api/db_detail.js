//数据库配置详情
module.exports = {
    host: 'localhost',
    user: 'xxie12_root',
    password: 'xxie12_root',
    database: 'xxie12_crowdfunding_db'
  };
  